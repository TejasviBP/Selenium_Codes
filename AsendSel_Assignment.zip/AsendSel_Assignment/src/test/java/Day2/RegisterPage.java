package Day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Day1.GetWebDriver;

public class RegisterPage {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver= GetWebDriver.getWebDriver();
		driver.get("http://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[1]/input")).sendKeys("Tejasvi");
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input")).sendKeys("Pathade");
		driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[2]/div/textarea")).sendKeys("Deolai, Aurangabad");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys("pathadetejasvi9@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input")).sendKeys("8793512723");
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[5]/div/label[2]/input")).click();
		driver.findElement(By.id("checkbox2")).click();
		Thread.sleep(3000);
		//driver.manage().window().maximize();

		WebElement language=driver.findElement(By.id("msdd"));
		language.click();
		driver.findElement(By.xpath("//li[@class='ng-scope']//a[@class='ui-corner-all'][contains(text(),'English')]")).click();

		WebElement skills= driver.findElement(By.id("Skills"));
		Select select= new Select(skills);
		select.selectByValue("CSS");

		//		WebElement country= driver.findElement(By.id("countries"));
		//		Select sel= new Select(skills);
		//		sel.selectByVisibleText("Select Country");

		List<WebElement>dynamicList =driver.findElements(By.xpath("//*[@id='country']//option[@value='India']"));
		for(int i=0;i<dynamicList.size(); i++) {
			String text= dynamicList.get(i).getText(); 
			System.out.println("text is "+text);             
			if(text.contains("India")) {
				dynamicList.get(i).click();
				break;	
			}
		}

		//Select Year
		WebElement	year = driver.findElement(By.id("yearbox"));
		Select selectYear= new Select(year);
		selectYear.selectByVisibleText("1999");


		//Select month		
		WebElement	month = driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[11]/div[2]/select"));
		Select selectMonth= new Select(month);
		selectMonth.selectByVisibleText("February");


		//select Date of Birth
		WebElement	date = driver.findElement(By.id("daybox"));
		Select selectDate= new Select(date);
		selectDate.selectByValue("9");

		driver.findElement(By.id("firstpassword")).sendKeys("Teju@123");
		driver.findElement(By.id("secondpassword")).sendKeys("Teju@123");

		WebElement fileUpload = driver.findElement(By.id("imagesrc"));
		fileUpload.sendKeys("C:\\Users\\TBHAUSAH\\OneDrive - Capgemini\\Pictures\\sm22.PNG");

		// Here, the country is not able to select, thus 'If' condition is used to say successful registration.

		WebElement subbutton = driver.findElement(By.id("submitbtn"));
		if(subbutton.isDisplayed()) {
			System.out.println("registration is successful");			
		}
		else{
			System.out.println("registration is failed");	
		}
		//	driver.findElement(By.id("submitbtn")).click();
		driver.quit();


	}

}
