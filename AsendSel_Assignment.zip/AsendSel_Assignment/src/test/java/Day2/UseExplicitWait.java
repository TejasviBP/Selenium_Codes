package Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Day1.GetWebDriver;

public class UseExplicitWait {

	public static void main(String[] args) {
		WebDriver driver=GetWebDriver.getWebDriver();    
		driver.get("http://www.google.com");
		WebElement searchbox= driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input"));
		searchbox.sendKeys("Apple");
        searchbox.submit();
    
    	WebElement firstElement= driver.findElement(By.xpath("//*[@id=\"tads\"]/div/div/div/div[1]/a/div[1]/span"));
    	WebDriverWait wait= new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.elementToBeClickable(firstElement));
        firstElement.click();
        System.out.println("Run successfully");
        driver.close();
	}

}
