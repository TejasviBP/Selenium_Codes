package Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GetAllLinks {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= GetWebDriver.getWebDriver();
		driver.get("https://www.bing.com/");

		List<WebElement> links=driver.findElements(By.tagName("a"));
		System.out.println("Total number of links present: "+links.size());
		System.out.println();

		for(int i=0; i<links.size(); i++) {
			String text= links.get(i).getText();
			if(text.isEmpty()) {
				System.out.println(i+"th link text is : [not accessible or not present]");
			}
			else	
				System.out.println(i+"th link text is : "+text);
		}
		Thread.sleep(3000);
		driver.quit();
	}

}
