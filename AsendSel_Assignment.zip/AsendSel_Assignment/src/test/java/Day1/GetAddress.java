package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GetAddress {

	public static void main(String[] args) {
		WebDriver driver= GetWebDriver.getWebDriver();
		driver.get("https://www.bing.com/");
		WebElement textField= driver.findElement(By.id("sb_form_q"));
		textField.sendKeys("Capgemini, India");
		textField.submit();
		
		WebElement address= driver.findElement(By.xpath("//*[@id=\"IconItem_14\"]/div/span"));
		String text =address.getText();
		System.out.println("Address: "+text);
		driver.close();
		
	}

}
