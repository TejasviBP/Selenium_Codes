package Day1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GetWebDriver {

	static WebDriver driver;

	public static WebDriver getWebDriver() {

		try {
			FileInputStream fis = new FileInputStream("configuration.properties");
			Properties prop = new Properties();
			prop.load(fis);
			String browserName = prop.getProperty("browser");

			if (browserName.equals("chrome")) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
//				System.setProperty("webdriver.chrome.driver",
//						"C:\\Users\\mhasanla\\eclipse-workspace\\AscendSelenium\\drivers\\chromedriver.exe");
//				driver = new ChromeDriver();
			}
			else if(browserName.equals("edge")) {
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				
				
//				System.setProperty("webdriver.edge.driver",
//						"C:\\Users\\mhasanla\\eclipse-workspace\\AscendSelenimMaven\\drivers\\msedgedriver.exe");
//				driver = new EdgeDriver();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().window().maximize();
		return driver;
	}

}
