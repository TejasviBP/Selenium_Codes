package Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GetImageSize {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= GetWebDriver.getWebDriver();
		driver.get("https://www.bing.com/");

		WebElement image= driver.findElement(By.xpath("//*[@id=\"images\"]/a"));
		Thread.sleep(3000);
		image.click();
		List <WebElement> allImages= driver.findElements(By.tagName("img"));
		System.out.println("total number of images present are " +allImages.size());
		Thread.sleep(5000);
		driver.quit();
	}

}
