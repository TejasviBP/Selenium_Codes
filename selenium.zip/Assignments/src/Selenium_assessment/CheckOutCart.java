package Selenium_assessment;
//ASSIGNMENT NO. 2
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CheckOutCart {
	
	public static void  main(String[] args) throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tejasvi\\Desktop\\Software\\chromedriver.exe");
      WebDriver driver = new ChromeDriver(); 
driver.get("http://demowebshop.tricentis.com/login");
driver.findElement(By.linkText("Log in")).click();
driver.findElement(By.id("Email")).sendKeys("pathadetejasvi9@gmail.com");
driver.findElement(By.id("Password")).sendKeys("Teju@123");
driver.findElement(By.xpath("//input[@value='Log in']")).click();

WebElement computer = driver.findElement(By.xpath("//ul[@class='top-menu']//a[contains(text(), 'Computers')]"));
Actions act = new Actions (driver);
act.moveToElement(computer).build().perform();
Thread.sleep(3000);

WebElement NoteBook = driver.findElement(By.xpath("//ul[@class='top-menu']//a[contains(text(), 'Notebooks')]"));
act.moveToElement(NoteBook).click().perform();
	
driver.findElement(By.xpath("//input[@value='Add to cart']")).click();	
driver.findElement(By.xpath("//span[@class='cart-label']")).click();
driver.findElement(By.xpath("//input[@id='termsofservice']")).click();
driver.findElement(By.xpath("//button[@value='checkout']")).click();

if(driver.findElement(By.linkText("Log out")).isDisplayed()) {
	System.out.println("Checkout failed");
}
else
{
	System.out.println("Checkout successful");
}
Thread.sleep(3000);
driver.findElement(By.linkText("Log out")).click();
	}

	}
