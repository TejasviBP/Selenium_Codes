package Selenium_assessment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

   //ASSIGNMENT NO. 4
public class RegisterAlerts {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tejasvi\\Desktop\\Software\\chromedriver.exe");
	         WebDriver driver = new ChromeDriver(); 
	  driver.get("http://demo.automationtesting.in/Register.html");
	  driver.manage().window().maximize();
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[1]/input")).sendKeys("Tejasvi");
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input")).sendKeys("Pathade");
	driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[2]/div/textarea")).sendKeys("Deolai, Aurangabad");
	 Thread.sleep(3000);
		
	driver.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys("pathadetejasvi9@gmail.com");
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input")).sendKeys("8793512723");
	driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[5]/div/label[2]/input")).click();
	driver.findElement(By.id("checkbox2")).click();
	  Thread.sleep(3000);
	  //driver.manage().window().maximize();

	 WebElement language=driver.findElement(By.id("msdd"));
	  Actions actn = new Actions (driver);
	
		 
	  actn.doubleClick(language).build().perform();
	
	  driver.findElement(By.xpath("//li[@class='ng-scope']//a[@class='ui-corner-all'][contains(text(),'English')]")).click();
	
	  driver.findElement(By.id("Skills"));
	  driver.findElement(By.xpath("//*[@id=\"Skills\"]/option[20]")).click();
	 
	  //driver.findElement(By.xpath("//*[@id=\"countries\"]/option")).click();
	  driver.findElement(By.xpath("//*[@id=\"countries\"]/option")).click();
	 // driver.findElement(By.xpath("//*[@id='country']//option[@value='India']")).click();
	
	  
	  
	  driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[10]/div/span/span[1]/span")).click();
	  List<WebElement>dynamicList =driver.findElements(By.xpath("//*[@id='country']//option[@value='India']"));
		 for(int i=0;i<dynamicList.size(); i++) {
			 String text= dynamicList.get(i).getText(); 
			 System.out.println("text is "+text);             
			 if(text.contains("India")) {
				dynamicList.get(i).click();
				break;	
		 }
		 }
		 driver.findElement(By.xpath("//*[@id=\"yearbox\"]/option[85]")).click();
		 driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[11]/div[2]/select/option[3]")).click();
		 driver.findElement(By.xpath("//*[@id=\"daybox\"]/option[10]")).click();
		  
	  
		 driver.findElement(By.id("firstpassword")).sendKeys("Teju@123");
		 driver.findElement(By.id("secondpassword")).sendKeys("Teju@123");
		 driver.findElement(By.id("imagesrc")).sendKeys("C://Users//Tejasvi//Pictures//girl_graphic.jpg");
		
		 
		
		 // Here, the country is not able to select, thus 'If' condition is used to say successful registration.
		
		 WebElement subbutton = driver.findElement(By.id("submitbtn"));
		 if(subbutton.isDisplayed()) {
System.out.println("registration is successful");			
		}
		else{
			System.out.println("registration is failed");	
		}
		 driver.findElement(By.id("submitbtn")).click();
	}
}
