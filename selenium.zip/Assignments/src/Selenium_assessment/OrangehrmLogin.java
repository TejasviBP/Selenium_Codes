package Selenium_assessment;
//ASSIGNMENT NO. 1
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class OrangehrmLogin {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tejasvi\\Desktop\\Software\\chromedriver.exe");
	        WebDriver driver = new ChromeDriver(); 
	 driver.get("https://opensource-demo.orangehrmlive.com/");
	          driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	          driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	          driver.findElement(By.xpath("//input[@value='LOGIN']")).click();
	          WebElement Username=driver.findElement(By.xpath("//a[@id='welcome']"));
	          Actions act = new Actions(driver);
	          act.moveToElement(Username).click().perform();
	  		  act.moveToElement(Username).build().perform();
	  		  WebElement Logout=driver.findElement(By.xpath("//div[@id='welcome-menu']//li//a[contains(text(),'Logout')]"));
			  Actions act1 = new Actions(driver);
			  act1.moveToElement(Logout).click().perform();

			  driver.quit();
		}
}
