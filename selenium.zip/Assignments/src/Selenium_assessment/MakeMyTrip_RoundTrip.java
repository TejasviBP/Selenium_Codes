package Selenium_assessment;

	import java.util.List;

	import org.openqa.selenium.By;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	public class MakeMyTrip_RoundTrip {
	
		public static void main(String[] args) throws InterruptedException {
				// TODO Auto-generated method stub
				 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tejasvi\\Desktop\\Software\\chromedriver.exe");
		         WebDriver driver = new ChromeDriver(); 
		  driver.get("https://www.makemytrip.com/flights/?cmp=SEM|D|DF|G|Brand|B_M_Makemytrip_Searc");
		  Thread.sleep(3000);
		    WebElement trip = driver.findElement(By.xpath("//li[@data-cy='roundTrip']"));
		  Actions acttrip = new Actions (driver);
		  Thread.sleep(3000);
	      
	     acttrip.doubleClick(trip).build().perform();
		  driver.findElement(By.xpath("//li[@data-cy='roundTrip']")).click();
		
		  Thread.sleep(3000);
	      
		  WebElement from = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[1]/label/span"));
		  Actions act = new Actions (driver);
		  act.doubleClick(from).build().perform();
			 Thread.sleep(3000);
		  driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div/input")).click();

	  Actions actn = new Actions (driver);
		  actn.doubleClick(from).build().perform();
		  driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div/input")).sendKeys("Bangalore,India");
		  Thread.sleep(3000);
		 List<WebElement>dynamicList =driver.findElements(By.xpath("//p[@class=\"font14 appendBottom5 blackText\"]"));
		 for(int i=0;i<dynamicList.size(); i++) {
			 String text= dynamicList.get(i).getText(); 
			 System.out.println("text is "+text);             
			 if(text.contains("Bengaluru, India")) {
				dynamicList.get(i).click();
				break;	
		 }
		 }
		 WebElement to = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[2]/label/span"));
		 Actions actv = new Actions (driver);
		 actv.doubleClick(to).build().perform();
		 Thread.sleep(3000);
		 
		 driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div[1]/input")).click();
			
		 Actions actp = new Actions (driver);
		 actp.doubleClick(to).build().perform();
		 driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div[1]/input")).sendKeys("Delhi,India");
		 Thread.sleep(3000);
		List<WebElement> dynamicLista =driver.findElements(By.xpath("//p[@class='font14 appendBottom5 blackText']"));
		for(int i=0;i<dynamicLista.size(); i++) {
			 String text= dynamicLista.get(i).getText(); 
			 System.out.println("text is "+text);
			 if(text.contains("New Delhi, India")) {
				dynamicLista.get(i).click();
				break;}
		}

		WebElement departure = driver.findElement(By.id("departure"));
		Thread.sleep(3000);
		Actions actd = new Actions (driver);
		actd.click(departure).build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[3]/div[4]")).click();

		WebElement retu = driver.findElement(By.id("return"));
		Thread.sleep(3000);	
		Actions actr = new Actions (driver);
		actr.click(retu).perform();
		Thread.sleep(3000);	
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[3]/div[6]")).click();

		driver.findElement(By.linkText("SEARCH")).click();
		 System.out.println("runned successfully");
		}

}

